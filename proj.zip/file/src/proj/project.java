
package proj;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class project {
    public static void main(String[] args) throws IOException {
        student []ar=new student[5];
        Scanner scan=new Scanner(System.in);
        FileWriter myfile=new FileWriter("student1.txt");
        for(int i=0;i<5;i++){
        ar[i]=new student();
        myfile.write("student "+i+"\n");
        System.out.println("enter student id "+i+": ");
        ar[i].student_id=scan.nextInt();
        myfile.write("id "+String.valueOf(ar[i].student_id+"\n"));
        System.out.println("enter student name "+i+": ");
        ar[i].student_name=scan.next();
        myfile.write("Name: "+ar[i].student_name+"\n");
        System.out.println("enter student gpa "+i+": ");
        ar[i].gpa=scan.nextFloat();
        myfile.write("gpa:"+String.valueOf(ar[i].gpa+"\n"));
        System.out.println("enter student mark "+i+": ");
        ar[i].marks=scan.nextFloat();
        myfile.write("the marks: "+String.valueOf(ar[i].marks+"\n"));
        }
        myfile.close();
       float sum=0;
        for(int i=0;i<5;i++){
            
            sum+=ar[i].marks;
    }
        float avrege=sum/5;
     System.out.println("\n The averge of marks is  "+avrege);

    

   }
    
    
}
