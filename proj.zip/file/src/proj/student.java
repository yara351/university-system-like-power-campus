
package proj;
public class student {
    int student_id;
    String student_name;
    float gpa,marks;
    public String toString(){
    return "name"+student_name+"\n"+"id ="+student_id+"\n"+"gpa = "+gpa+"\n"+"marks = "+marks;
    
    }
    
    
}
